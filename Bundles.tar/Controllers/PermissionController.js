const PermissionService = require("../Services/PermissionService");
const Responses = require("../Services/ResponseService");

const changePermission = async (req, res) => {
  try {
    const status = await PermissionService.changePermission(
      req.user,
      req.body.usie,
      req.body.role
    );
    return res.json(status);
  } catch (err) {
    console.log(err.toString());
    return res.json(Responses.Error("Some error occurred!"));
  }
};

module.exports = { changePermission };
