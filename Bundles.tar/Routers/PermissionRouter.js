const router = require("express").Router();
const IdentifyUserMiddleware = require("../Middlewares/IdentifyUserMiddleware");
const PermissionController = require("../Controllers/PermissionController");
router.post(
  "/changePermission",
  [IdentifyUserMiddleware.IdentifyUserMiddleware],
  PermissionController.changePermission
);

module.exports = router;
