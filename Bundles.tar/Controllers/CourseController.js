const Response = require("../Services/ResponseService");
const CourseService = require("../Services/CourseService");
var Course = require("../Models/Course");
var Request = require("../Models/Request");
var Temporary = require("../Models/DummyCourse");

const addCourse = async (req, res) => {
  console.log("hi");
  const coursePayload = req.body;
  const courseExists = await Course.findOne({
    code: coursePayload.code,
    instructorId: coursePayload.instructorId,
  });
  console.log(courseExists);
  if (courseExists) {
    res.status(401).send({ message: "Course already exists" });
    return;
  }
  const course = await new Course(coursePayload);
  const request = await new Request({
    courseCode: coursePayload.code,
    requestType: "Creation",
    instructorId: coursePayload.instructorId,
    courseName: coursePayload.name,
  });
  try {
    await course.save(course);
    res
      .status(200)
      .send({ message: "Course created and pending for approval" });
    await request.save(request);
    return;
  } catch (err) {
    console.log(err.toString());
    return res.json(Response.Error("Error adding course"));
  }
};

const updateCourse = async (req, res) => {
  const payload = req.body;
  const course = await Course.findOne({ code: payload.code });
  if (!course) {
    res.status(401).send({ message: "Course not found" });
  }
  try {
    const temporary = await new Temporary(coursePayload);
    temporary.save();

    const request = await new Request({
      courseCode: payload.code,
      requestType: "Updation",
      instructorId: coursePayload.instructorId,
    });
    //const restoupdate=await Course.findOneAndUpdate({code:payload.code,...payload, approved:false});
    console.log(restoupdate);
    await request.save();
    res.status(200).send({ message: "Request sent" });
    return;
  } catch (err) {
    console.log(err);
    return res.json(Response.Error("Error updating course"));
  }
};

const deleteCourse = async (req, res) => {
  try {
    const courseID = req.body.courseID;
    const status = await CourseService.deleteCourse(courseID);
    return res.json(status);
  } catch (err) {
    console.log(err.toString());
    return res.json(Response.Error("Error deleting course"));
  }
};





const getCourses = async (req, res) => {
  try {
      const requests = await Course.find({approved:true});
      res.status(200).send({ requests });
  }
  catch (e) {
      res.status(500).send({ message: 'error' })
  }

}

module.exports = { addCourse, deleteCourse, updateCourse, getCourses };
