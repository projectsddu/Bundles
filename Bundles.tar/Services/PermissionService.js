const AuthService = require("./AuthService");
const Responses = require("./ResponseService");

const changePermission = async (A, B, toRole) => {
  try {
    const rolesMapping = { admin: 3, instructor: 2, student: 1 };
    const BUser = await AuthService.getuserById(B);
    if (
      rolesMapping[A.role] > rolesMapping[BUser.role] &&
      rolesMapping[toRole] <= rolesMapping[A.role]
    ) {
      const status1 = await AuthService.updateUser(BUser.username, {
        role: toRole,
      });
      if (status1) {
        return Responses.Success("Successfully changed the role!");
      }
    } else {
      return Responses.Error("Some error occurred!");
    }
  } catch (err) {
    console.log(err.toString());
    return Responses.Error("Some error occurred!");
  }
};

module.exports = { changePermission };
