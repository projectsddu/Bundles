const CourseSchema = require("../Models/Course");
const Response = require("./ResponseService");
const addCourse = async (payload) => {
  try {
    if (payload.courseName) {
      const status = await CourseSchema.create(payload);
      if (status) {
        return true;
      }
      return Response.Error("No course name provided");
    }
  } catch (err) {
    console.log(err.toString());
    return Response.Error("Error adding course");
  }
};

module.exports = { addCourse };
