const mongoose = require("mongoose");

const AssignmentSchema = new mongoose.Schema({
  title: {
    type: String,
  },
  description: {
    type: String,
  },
  deadline: {
    type: Date,
  },
});

module.exports = mongoose.model("Assignment", AssignmentSchema);
