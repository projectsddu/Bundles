const mongoose = require("mongoose");
const User = require("./User");
const CourseSchema = new mongoose.Schema({
  courseName: {
    type: String,
  },
  courseDescription: {
    type: String,
  },
  courseNumber: {
    type: String,
  },
  students: {
    type: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "UserSigned",
      },
    ],
  },
  instructor: {
    type: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "UserSigned",
    },
  },
});

module.exports = mongoose.model("Courses", CourseSchema);
