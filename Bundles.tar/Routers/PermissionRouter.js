const router = require("express").Router();
const IdentifyUserMiddleware = require("../Middlewares/IdentifyUserMiddleware");
const PermissionController = require("../Controllers/PermissionController");
const {
  InstructorIdentifierMiddleware,
} = require("../Middlewares/InstructorIdentifierMiddleware");
router.post(
  "/changePermission",
  // [
  //   IdentifyUserMiddleware.IdentifyUserMiddleware,
  //   InstructorIdentifierMiddleware,
  // ],
  PermissionController.changePermission
);

router.post("/assignInstructorRole", PermissionController.assignInstructorRole);

module.exports = router;
