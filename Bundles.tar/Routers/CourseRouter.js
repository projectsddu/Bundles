const router = require("express").Router();
const IdentifyUserMiddleware = require("../Middlewares/IdentifyUserMiddleware");
const InstructorIdentifierMiddleware = require("../Middlewares/InstructorIdentifierMiddleware");
const CourseController = require("../Controllers/CourseController");
router.post(
  "/addCourse",
  [
    IdentifyUserMiddleware.IdentifyUserMiddleware,
    InstructorIdentifierMiddleware.InstructorIdentifierMiddleware,
  ],
  CourseController.addCourse
);

module.exports = router;
