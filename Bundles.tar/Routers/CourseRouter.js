const router = require("express").Router();
const IdentifyUserMiddleware = require("../Middlewares/IdentifyUserMiddleware");
const InstructorIdentifierMiddleware = require("../Middlewares/InstructorIdentifierMiddleware");
const CourseController = require("../Controllers/CourseController");
router.post(
  "/addCourse",
  // [
  //   IdentifyUserMiddleware.IdentifyUserMiddleware,
  //   InstructorIdentifierMiddleware.InstructorIdentifierMiddleware,
  // ],
  CourseController.addCourse
);


router.get(
  "/courses",
  // [
  //   IdentifyUserMiddleware.IdentifyUserMiddleware,
  //   InstructorIdentifierMiddleware.InstructorIdentifierMiddleware,
  // ],
  CourseController.getCourses
);


//My changes
router.delete(
  "/deleteCourse",
  // [
  //   IdentifyUserMiddleware.IdentifyUserMiddleware,
  //   InstructorIdentifierMiddleware.InstructorIdentifierMiddleware,
  // ],
  CourseController.deleteCourse
);

router.put("/updateCourse", CourseController.updateCourse);
module.exports = router;
