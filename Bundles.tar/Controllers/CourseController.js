const Response = require("../Services/ResponseService");
const CourseService = require("../Services/CourseService");
const addCourse = async (req, res) => {
  try {
    const payLoad = req.body.data;
    payLoad.instructor = req.user;
    const status = await CourseService.addCourse(payLoad);
    if (status) {
      return res.json(Response.Success("Course added successfully"));
    }
    return res.json(status);
  } catch (err) {
    console.log(err.toString());
    return res.json(Response.Error("Error adding course"));
  }
};

module.exports = { addCourse };
